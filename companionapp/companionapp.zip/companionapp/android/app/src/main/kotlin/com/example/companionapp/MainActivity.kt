package com.example.companionapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
