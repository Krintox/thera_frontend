import 'package:flutter/material.dart';

class SensoryIntegration extends StatefulWidget{
  const SensoryIntegration({Key? key}) : super(key: key);

  @override
  _SensoryIntegrationState createState() => _SensoryIntegrationState();
}

class _SensoryIntegrationState extends State<SensoryIntegration> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        backgroundColor: Colors.green[300],
        title: Text('Sensory Integration'),
      ),
    );
  }
}