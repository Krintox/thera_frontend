import 'package:flutter/material.dart';

class ProgressTracking extends StatefulWidget {
  const ProgressTracking({Key? key}) : super(key: key);

  @override
  _ProgressTrackingState createState() => _ProgressTrackingState();
}

class _ProgressTrackingState extends State<ProgressTracking> {
  // Sample data for progress metrics
  double completionRate = 0.8;
  double accuracy = 0.75;
  double timeTaken = 2.5; // in hours
  List<double> historicalData = [0.6, 0.7, 0.8, 0.85, 0.9]; // Sample historical data

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text('Progress Tracking'),
        backgroundColor: Colors.grey[500],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Visual Progress Box
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Visual Progress',
                    style: TextStyle(color: Colors.white, fontSize: 18.0),
                  ),
                  SizedBox(height: 8.0),
                  LinearProgressIndicator(
                    value: completionRate,
                    color: Colors.green[200],
                    backgroundColor: Colors.grey[700],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            // Metrics Box
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Metrics',
                    style: TextStyle(color: Colors.white, fontSize: 18.0),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Completion Rate: ${(completionRate * 100).toStringAsFixed(0)}%',
                    style: TextStyle(color: Colors.white),
                  ),
                  Text(
                    'Accuracy: ${(accuracy * 100).toStringAsFixed(0)}%',
                    style: TextStyle(color: Colors.white),
                  ),
                  Text(
                    'Time Taken: ${timeTaken.toStringAsFixed(1)} hours',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            // Historical Data Box
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Historical Data',
                    style: TextStyle(color: Colors.white, fontSize: 18.0),
                  ),
                  SizedBox(height: 8.0),
                  Container(
                    height: 100.0,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: historicalData.length,
                      itemBuilder: (context, index) {
                        return Container(
                          width: 30.0,
                          height: historicalData[index] * 100,
                          color: Colors.green[200],
                          margin: EdgeInsets.symmetric(horizontal: 2.0),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}



