import 'package:flutter/material.dart';

class FineMotorSkills extends StatefulWidget {
  const FineMotorSkills({Key? key}) : super(key: key);

  @override
  _FineMotorSkillsState createState() => _FineMotorSkillsState();
}

class _FineMotorSkillsState extends State<FineMotorSkills> {
  // Sample data for progress metrics
  double completionRate = 0.8;
  double accuracy = 0.75;
  double timeTaken = 2.5; // in hours
  List<double> historicalData = [0.6, 0.7, 0.8, 0.85, 0.9]; // Sample historical data

  String? selectedExercise;
  String? selectedGameActivity;

  List<String> exercises = [
    'Hand-eye coordination',
    'Grip strength',
    'Finger dexterity',
    'Precision movements'
  ];

  List<String> gameActivities = [
    'Trace the Path',
    'Stacking Blocks',
    'Puzzle Solving'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text('Fine Motor Skills'),
        backgroundColor: Colors.green[300],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Exercises Dropdown
            Text(
              'Exercises',
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(height: 8.0),
            DropdownButtonFormField<String>(
              value: selectedExercise,
              onChanged: (value) {
                setState(() {
                  selectedExercise = value;
                });
              },
              items: exercises.map((String exercise) {
                return DropdownMenuItem<String>(
                  value: exercise,
                  child: Text(exercise, style: TextStyle(color: Colors.white)),
                );
              }).toList(),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.grey[800],
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green[200]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green[200]!),
                ),
              ),
              style: TextStyle(color: Colors.white),
              dropdownColor: Colors.grey[800],
            ),
            SizedBox(height: 16.0),
            // Game Activities Dropdown
            Text(
              'Game Activities',
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(height: 8.0),
            DropdownButtonFormField<String>(
              value: selectedGameActivity,
              onChanged: (value) {
                setState(() {
                  selectedGameActivity = value;
                });
              },
              items: gameActivities.map((String activity) {
                return DropdownMenuItem<String>(
                  value: activity,
                  child: Text(activity, style: TextStyle(color: Colors.white)),
                );
              }).toList(),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.grey[800],
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green[200]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green[200]!),
                ),
              ),
              style: TextStyle(color: Colors.white),
              dropdownColor: Colors.grey[800],
            ),
            SizedBox(height: 16.0),
            // Show Video Placeholder based on selection
            if (selectedExercise != null || selectedGameActivity != null)
              SizedBox(height: 25.0),
              Container(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      // Full Video Placeholder
                      Container(
                        width: 200,
                        height: 200, // Square box
                        color: Colors.grey[700],
                        child: Center(
                          child: Text(
                            'Video Placeholder',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}


