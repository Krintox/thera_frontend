import 'package:flutter/material.dart';

class CognitiveAbilities extends StatefulWidget {
  const CognitiveAbilities({Key? key}) : super(key: key);

  @override
  _CognitiveAbilitiesState createState() => _CognitiveAbilitiesState();
}

class _CognitiveAbilitiesState extends State<CognitiveAbilities> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text('Cognitive Abilities'),
        backgroundColor: Colors.green[300],
      ),
    );
  }
}
