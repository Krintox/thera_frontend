import 'package:flutter/material.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  String _username = 'Saumya';
  String _email = 'Saumya@example.com';
  String _password = '********'; // Placeholder for password

  void changeUsername(String newUsername) {
    setState(() {
      _username = newUsername;
    });
  }

  void changeEmail(String newEmail) {
    setState(() {
      _email = newEmail;
    });
  }

  void changePassword(String newPassword) {
    setState(() {
      _password = newPassword;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text('Settings'),
        backgroundColor: Colors.green[300],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Profile Settings',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 16),
            ListTile(
              title: Text(
                'Username',
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                _username,
                style: TextStyle(color: Colors.grey),
              ),
              trailing: IconButton(
                icon: Icon(Icons.edit, color: Colors.white),
                onPressed: () {
                  // Add logic to edit username
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: Colors.grey[800],
                      title: Text('Change Username', style: TextStyle(color: Colors.white)),
                      content: TextField(
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Enter new username',
                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                        onChanged: (value) {
                          // Update username
                          changeUsername(value);
                        },
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Cancel', style: TextStyle(color: Colors.white)),
                        ),
                        TextButton(
                          onPressed: () {
                            // Save changes to username
                            Navigator.pop(context);
                          },
                          child: Text('Save', style: TextStyle(color: Colors.green[200])),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Divider(color: Colors.grey[600]),
            ListTile(
              title: Text(
                'Email',
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                _email,
                style: TextStyle(color: Colors.grey),
              ),
              trailing: IconButton(
                icon: Icon(Icons.edit, color: Colors.white),
                onPressed: () {
                  // Add logic to edit email
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: Colors.grey[800],
                      title: Text('Change Email', style: TextStyle(color: Colors.white)),
                      content: TextField(
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Enter new email',
                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                        onChanged: (value) {
                          // Update email
                          changeEmail(value);
                        },
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Cancel', style: TextStyle(color: Colors.white)),
                        ),
                        TextButton(
                          onPressed: () {
                            // Save changes to email
                            Navigator.pop(context);
                          },
                          child: Text('Save', style: TextStyle(color: Colors.green[200])),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Divider(color: Colors.grey[600]),
            ListTile(
              title: Text(
                'Password',
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                _password,
                style: TextStyle(color: Colors.grey),
              ),
              trailing: IconButton(
                icon: Icon(Icons.edit, color: Colors.white),
                onPressed: () {
                  // Add logic to edit password
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: Colors.grey[800],
                      title: Text('Change Password', style: TextStyle(color: Colors.white)),
                      content: TextField(
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Enter new password',
                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                        onChanged: (value) {
                          // Update password
                          changePassword(value);
                        },
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Cancel', style: TextStyle(color: Colors.white)),
                        ),
                        TextButton(
                          onPressed: () {
                            // Save changes to password
                            Navigator.pop(context);
                          },
                          child: Text('Save', style: TextStyle(color: Colors.green[200])),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
